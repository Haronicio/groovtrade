# Getting Started with Create React App

installation:

npm i

npm install react-toastify

npm install axios

npm install react-icons

pour lancer l'application:

npm start